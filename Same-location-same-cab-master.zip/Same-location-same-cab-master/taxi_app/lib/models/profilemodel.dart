class Profilee{
  static Map<String,dynamic> mydefineduser={};
}